#!/usr/bin/env bash
set -euo pipefail
STAMP="${XDG_CONFIG_HOME:-$HOME/.config}/valhalla-firstboot.done"
[ -f "$STAMP" ] && exit 0
have(){ command -v "$1" >/dev/null 2>&1; }
zen(){ have zenity && zenity "$@" || true; }
zen --info --title="ValhallaOS" --text="Welcome to ValhallaOS!\nLet’s do a quick setup." || true
if zen --question --text="Enable Flathub system-wide?"; then
  if command -v flatpak >/dev/null 2>&1; then
    sudo -n flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo || true
  fi
fi
PROFILE=$(zen --list --radiolist --column "Pick" --column "Profile" TRUE "Gamer + Work" FALSE "Work Focus" FALSE "Minimal" 2>/dev/null || echo "Gamer + Work")
case "$PROFILE" in
  "Work Focus") notify-send "ValhallaOS" "Work focus presets applied.";;
  "Minimal")    notify-send "ValhallaOS" "Minimal presets applied.";;
  *)            notify-send "ValhallaOS" "Gamer + Work presets applied.";;
esac
mkdir -p "$(dirname "$STAMP")"; touch "$STAMP"
zen --info --text="All set! Enjoy ValhallaOS." || true
