#!/usr/bin/env bash
set -euo pipefail
. /etc/valhalla/laptop-tweaks.conf 2>/dev/null || true
command -v powerprofilesctl >/dev/null 2>&1 && powerprofilesctl set "${POWER_PROFILE:-balanced}" || true
if command -v iw >/dev/null 2>&1; then
  iw dev 2>/dev/null | awk '/Interface/ {print $2}' | xargs -r -I{} iw dev {} set power_save on
fi
