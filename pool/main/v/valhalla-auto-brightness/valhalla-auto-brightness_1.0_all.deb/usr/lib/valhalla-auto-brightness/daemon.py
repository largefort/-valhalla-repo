#!/usr/bin/env python3
import time, subprocess, datetime
def set_brightness(percent):
    try: subprocess.run(["brightnessctl","set",f"{percent}%"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except FileNotFoundError: pass
def on_ac_power():
    try:
        out = subprocess.check_output(["upower","-i","/org/freedesktop/UPower/devices/line_power_AC"], text=True, stderr=subprocess.DEVNULL)
        return "online:             yes" in out
    except Exception: return True
while True:
    now = datetime.datetime.now().hour
    ac = on_ac_power()
    target = (35 if ac else 25) if (22 <= now or now < 7) else (80 if ac else 60)
    set_brightness(target)
    time.sleep(300)
